# 1.USA.gov Data

We recently performed an evaluation on 1.USA.gov and found that the number of people who use the service is declining, and there is not strong support to continue the service.    As a result, we have decided to  deactivate the service on June 30, 2016.  You can read more about this decision on the [USAGov Blog](https://blog.usa.gov/decommissioning-1-usa-gov).

This change will mean that the 1.USA.gov data stream will cease to work beginning in July 2016.